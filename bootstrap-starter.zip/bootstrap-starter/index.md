---
layout: home
title: Get started with Bootstrap
---

# {{page.title}}

Quickly and easily get started with Bootstrap's compiled, production-ready files with this barebones example featuring some basic HTML. I wanted to create a really simple theme for newbies to hack on that already comes with Bootstrap. I will add more to this as the downloads grow. If you would like to get in touch please consider joining the HDG developer chat on Discord and let's talk.

For now the "site" is structured as follows:

```
|-- index.md   = Home Page
|-- blog.md    = Index of posts
|-- about.md   = About Page
|-- /posts
|    [...posts]
```

<a href="#" class="btn btn-primary btn-lg px-4">Download ZIP</a>

<hr class="col-3 col-md-2 mb-5">