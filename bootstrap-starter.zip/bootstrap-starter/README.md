# Bootstrap Starter Template

A basic bootstrap 5 starter theme for your jekyll blog. I just started this template so it is very basic and missing most of the components I want to include, stay tuned for updates.

## [CHANGELOG](CHANGELOG)

## LICENSE 

[Mozilla Public License v2.0](LICENSE)